package com.blackandyellow.greenpigsapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	EditText usernameField;
	EditText passwordField;
	String username, password;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Typeface tf = Typeface.createFromAsset(getAssets(), "fonts/Arvo-Regular.ttf");
		
		usernameField = (EditText) findViewById(R.id.usernameField);
		passwordField = (EditText) findViewById(R.id.passwordField);
		
		usernameField.setGravity(Gravity.CENTER);
		passwordField.setGravity(Gravity.CENTER);
		
		TextView user = (TextView)findViewById(R.id.username_label);
		TextView pass = (TextView)findViewById(R.id.password_label);
		Button button = (Button)findViewById(R.id.button1);
		
		user.setTypeface(tf);
		pass.setTypeface(tf);
		button.setTypeface(tf);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void login(View view){
		//Toast.makeText(this, "You know what it is", Toast.LENGTH_LONG).show();
		
		username = usernameField.getText().toString();
		password = passwordField.getText().toString();
		/*
		if (cb.isChecked()) {
			SharedPreferences prefs = this.getSharedPreferences(
					"com.example.androidproject", MODE_PRIVATE);
			prefs.edit().putString("user", username)
					.commit();
			prefs.edit().putString("pass", password)
					.commit();
			prefs.edit().putBoolean("cbIsChecked", true).commit();
		} else {
			SharedPreferences prefs = this.getSharedPreferences(
					"com.example.androidproject", MODE_PRIVATE);
			prefs.edit().clear().commit();
		}*/

		registerReceiver(closer, new IntentFilter("closeLogin"));
		new SignInServiceActivity(this).execute(username, password);
		
	}
	
	private final BroadcastReceiver closer = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
              finish();                                   
        }
    };
	
	
}

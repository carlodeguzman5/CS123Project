package com.blackandyellow.greenpigsapplication;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class MenuActivity extends TabActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);
		
		
		TabHost tabHost = getTabHost();
        
        // Tab for Food
        TabSpec foodSpec = tabHost.newTabSpec("Food");
        // setting Title and Icon for the Tab
        foodSpec.setIndicator("Food");
        Intent foodIntent = new Intent(this, FoodTabActivity.class);
        foodSpec.setContent(foodIntent);
         
        // Tab for Gift
        TabSpec giftSpec = tabHost.newTabSpec("Gifts");        
        giftSpec.setIndicator("Gifts");
        Intent songsIntent = new Intent(this, GiftTabActivity.class);
        giftSpec.setContent(songsIntent);
                  
        // Adding all TabSpec to TabHost
        tabHost.addTab(foodSpec);
        tabHost.addTab(giftSpec); 
        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
